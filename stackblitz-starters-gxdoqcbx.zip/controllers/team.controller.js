exports.team = (req, res) => {
  res.json({ teamSize: 12 });
};