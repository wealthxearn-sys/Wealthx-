exports.startReserve = (req, res) => {
  res.json({ status: "Reserve started" });
};